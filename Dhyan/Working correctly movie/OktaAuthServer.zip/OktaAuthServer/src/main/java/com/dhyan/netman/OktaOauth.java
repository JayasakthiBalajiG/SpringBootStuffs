package com.dhyan.netman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@SpringBootApplication
@RestController
public class OktaOauth {

	public static void main(String[] args) {
		SpringApplication.run(OktaOauth.class, args);
	}


	/**
	 * This endpoint can be accessed by all people who are in the groups
	 * URI: /greetings
	 * HTTP method: GET
	 */
	@GetMapping("/greetings")
	public String helloAll(Principal principal){
		return "Hi " + principal.getName();
	}

}
