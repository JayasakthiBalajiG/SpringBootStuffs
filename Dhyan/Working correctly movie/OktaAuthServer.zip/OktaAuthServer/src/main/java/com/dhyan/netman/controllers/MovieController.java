package com.dhyan.netman.controllers;

import com.dhyan.netman.model.Movie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@RestController
public class MovieController {



    /**
     * This endpoint is only restricted to use by ADMINS.
     * URI: /allmovies
     * HTTP method: GET
     */
    @GetMapping("/allmovies")
    @PreAuthorize("hasAuthority('ADMINS')")
    public ResponseEntity<List<Movie>> getAllMovies() {
        System.out.println("worked");
        List<Movie> movies = new ArrayList<>();
        Movie nextGen = new Movie();
        nextGen.setMovieId(1);
        nextGen.setMovieName("hello");
        nextGen.setGenre("fantasy");
        nextGen.setDirector("Balaji");
        nextGen.setComments("good");
        movies.add(nextGen);
        return new ResponseEntity<>(movies, HttpStatus.OK);
    }

    /**
     * This endpoint is only restricted to use by USERS.
     * URI: /users
     * HTTP method: GET
     */
    @GetMapping("/users")
    @PreAuthorize("hasAuthority('USERS')")
    public String usersFunc(Principal principal){
        return "Hi user  " + principal.getName();
    }

    /**
     * This endpoint can be accessed by all people who are in the groups
     * URI: /
     * HTTP method: GET
     */
    @GetMapping("/")
    public String Test(Principal principal){
        return "Hi"+principal.getName() + " hi";
    }


}
