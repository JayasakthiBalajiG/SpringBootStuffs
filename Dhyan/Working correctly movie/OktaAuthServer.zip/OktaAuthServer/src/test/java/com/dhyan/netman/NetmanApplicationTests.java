package com.dhyan.netman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetmanApplicationTests {

	@Test
	void contextLoads() {
	}

}
